package Model.cart;

import java.util.ArrayList;

public interface CartDao <E extends Exception> {

}
